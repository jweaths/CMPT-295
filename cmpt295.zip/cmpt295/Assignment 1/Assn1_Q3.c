/* 
 * Filename: Assn1_Q3.c
 *
 * Description: CMPT 295 Assignment 1 Q3
 *
 * Authors: AL + Jack Weatherbe
 * Student number: 301466197
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

typedef unsigned char *byte_pointer;

// Question 3 a.
void show_bytes(byte_pointer start, size_t len) {
  size_t i;
  for (i = 0; i < len; i++) {
 	
 	printf( "%p", &start[i] ) ; // 
 	printf( "   0x") ;
    printf(" %.2x", start[i]) ; 	
  	printf("\n") ;
  	
  	}
  	
  return;	
}

/* 

SAMPLE OUTPUT:

ival = 12345
0x7ffe5ecd70fc   0x 39
0x7ffe5ecd70fd   0x 30
0x7ffe5ecd70fe   0x 00
0x7ffe5ecd70ff   0x 00

Endian represents the order in which bytes are stored in memory. Our machine is running on little endian because the least signifiant byte (0x 00) is stored at the lowest memory address and the most significant byte (0x 39) is stored at the highest memory address.

*/


// Question 3 b.
// Put your answer to Question 3 b) here as a comment




// Question 3 c.
void show_bytes_2(byte_pointer start, size_t len) {
  size_t i;
  for (i = 0; i < len; i++) {
 	
 	printf( "%d", *(start + i) ); // 
 	printf( "   0x") ;
    printf(" %.2x", *(start + i) ) ; 	
  	printf("\n") ;
  	
  	}
  return;		
}

// Question 3 d.
void show_bits(int decimal) {
	
  // utilze the subraction method
  
  	int zero = 0 ;
  	int one = 1 ;
  	int two = 2 ;
  	int number = 0;
  	int carry = 1;
  	int remainder = 0; // will represent the current bit being added
  	

	const int MAXSIZE = 32 ;

	int bitPattern[MAXSIZE]	 ;
	
	
  	int index = 0 ;
  	
  	
  	printf("\n") ;
  	
  	if( decimal < 0) {
  	
  		for(int i = 0; i < MAXSIZE; i++ ) {
	
	
		bitPattern[i] = 1 ;
	
		}
		
		decimal = decimal * -1 ; // makes negative positive


		while( decimal > 0 ) {
	
	
			number = decimal / 2 ;
			
			if(number*2 != decimal) {
				
				remainder = 0; // accounts for toggle
					
					if(carry == 1) {
					
						carry = 0;
						remainder = 1;
						bitPattern[index] = remainder;
						index++;
					
					}
					
					else {
					bitPattern[index] = remainder;
					index++;
					}
			
			}
			
			
				
			else {
				remainder = 1;
				
					if(carry == 1) {
						
							remainder = 0; // carried 1 makes bit zero
							bitPattern[index] = remainder;
							index++;
						
						}
					else
					bitPattern[index] = remainder;
					index++;
					
				
				}
			
			decimal = number ;
				
		
		}
		
		index = MAXSIZE ;
			
		while(index > 0) { // for printing
		
		  	printf("%d", bitPattern[index-1]) ;
		  	index-- ;
		  
		  }
		  
		  
		 printf("\n") ;
				
	
	}
	
	
	else {
	
	for(int i = 0; i < MAXSIZE; i++ ) {
	
	
		bitPattern[i] = 0 ;
	
	}
	
	while( decimal > 0 ) {
	
		number = decimal / 2 ;
	
		if(number*2 != decimal) {
				
				remainder = 1; 
				bitPattern[index] = remainder;
				index++;
		
		}
		
		else {
				remainder = 0;
				bitPattern[index] = remainder;
				index++;
		
		}
		
		decimal = number ;
	
	
	}
	
	// printf("%d \n", index) ;
	
	index = 32;
	
	while(index > 0) { // for printing
		
		  	printf("%d", bitPattern[index-1]) ;
		  	index-- ;
		  
	}
		  
		    
	printf("\n") ;
  
  
  }
  
  
  printf("\n") ;

  return; 
}	


// Question 3 e.
int mask_LSbits(int n) {

	int mask = (1 << n) - 1; // subtracting 1 removes the leftmost bit that was turned on by the left shift opreator
  
  return mask;
}

void show_int(int x) {
  printf("\nival = %d\n", x); 
  show_bytes((byte_pointer) &x, sizeof(int)); 
  show_bytes_2((byte_pointer) &x, sizeof(int)); 
  return;	
}

void show_float(float x) {
  printf("fval = %f\n", x); 	
  show_bytes((byte_pointer) &x, sizeof(float));
  show_bytes_2((byte_pointer) &x, sizeof(float)); 
  return;	
}

void show_pointer(void *x) {
  printf("pval = %p\n", x); 
  show_bytes((byte_pointer) &x, sizeof(void *));
  show_bytes_2((byte_pointer) &x, sizeof(void *));
  return;	
}
