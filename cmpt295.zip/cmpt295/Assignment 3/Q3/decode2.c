/*


decode2.c

Q3 Assignment 3

February 3, 2023

JW

*/


#include <stdio.h>


long decode2(long x, long y, long z) {

	// x is %rdi
	// y is %rsi
	// z is %rdx
	// t is %rax
	
	long t; // %rax
		


	
	y = y - z; 	
	
	x = x * y;	
	
	t = y;		
	
	t = t << 63; 	// 	63 bit shifts to the left
	
	t = t >> 63; 	//	63 bit shifts to the right
	
	t = (t ^ x); 	//	compares bit values of the variables. Places 1 in bit position if either has a 1, but not both.
	
	return t; 	

	
		



}



int main(void) {

	
	
	
	
	// TEST CASE 1 - Positive Values
	
	long x = 20;
	long y = 30;
	long z = 40;


	decode2(x, y, z);
	
	
	// TEST CASE 2 - Negative Values
	
	long a = -20;
	long b = -30;
	long c = -40;
	
	decode2(a, b, c);
	
	
	// USER INPUT
	

	long q;
	long r;
	long s;
	
	
	printf("Enter three values: \n \n" );
	printf("X = ");
	scanf("%ld", &q);
	printf("\n");
	
	printf("Y = ");
	scanf("%ld", &r);
	printf("\n");
	
	printf("Z = ");
	scanf("%ld", &s);
	printf("\n");
	
	
	r = decode2(q, r, s);
	
	
	printf("Returned value: %ld \n", r);
	
	
	


	return 0;
	

}




