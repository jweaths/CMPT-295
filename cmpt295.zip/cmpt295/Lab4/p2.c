/* 
 * Filename: p2.c
 *
 * Description: p2.c for our Lab 4.
 *
 * Auhtor:
 * Modification date: Feb. 2023
 */
 
int proc2(int m, int n) {
    int res;
    res = m*n - 12;
    return res;
}
