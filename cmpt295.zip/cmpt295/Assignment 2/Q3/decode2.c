/*

Q3 Assignment 3

February 3, 2023

JW

*/


#include <stdio.h>


long decode2(long x, long y, long z) {

	// x is %rdi
	// y is %rsi
	// z is %rdx
	
	long t; // %rax
		


	
	y = y - z; 	//	subq  %rdx, %rsi
	
	x = x * y;	//	imulq  %rsi, %rdi
	
	t = y;		//	movq %rsi, %rax
	
	t = t << 63; // salq $63, %rax
	
	t = t >> 63; //sarq $63, %rax
	
	t = (t ^ x); //xorq %rdi, %rax (zeros register)
	
	return t; // ret

	
		



}



int main(void) {


	long x = 20;
	long y = 30;
	long z = 40;


	decode2(x, y, z);


	return 0;
	

}

// ---------------------------------------------------------------------
//  decode.s

	.file	"decode2.c"
	.text
	.globl	decode2
	.type	decode2, @function
decode2:
.LFB23:
	

	# mappings
	# x = %rdi
	# y = %rsi
	# z = %rdx
	# t = %rax
	
	
	
	.cfi_startproc
	endbr64
	subq	%rdx, %rsi	# y = y - z;
	imulq	%rsi, %rdi	# x = x * y;
	salq	$63, %rsi	# y = y << 63
	sarq	$63, %rsi	# y = y >> 63;
	movq	%rdi, %rax	# t = x;
	xorq	%rsi, %rax	# t = (t ^ y);
	ret					# return t;
	.cfi_endproc
.LFE23:
	.size	decode2, .-decode2
	.section	.rodata.str1.1,"aMS",@progbits,1
.LC0:
	.string	"Enter three values: \n "
.LC1:
	.string	"X = "
.LC2:
	.string	"%ld"
.LC3:
	.string	"Y = "
.LC4:
	.string	"Z = "
.LC5:
	.string	"Returned value: %ld \n"
	.text
	.globl	main
	.type	main, @function
main:
.LFB24:
	.cfi_startproc
	endbr64
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	subq	$32, %rsp
	.cfi_def_cfa_offset 48
	movl	$40, %ebx
	movq	%fs:(%rbx), %rax
	movq	%rax, 24(%rsp)
	xorl	%eax, %eax
	leaq	.LC0(%rip), %rdi
	call	puts@PLT
	leaq	.LC1(%rip), %rsi
	movl	$1, %edi
	movl	$0, %eax
	call	__printf_chk@PLT
	movq	%rsp, %rsi
	leaq	.LC2(%rip), %rdi
	movl	$0, %eax
	call	__isoc99_scanf@PLT
	movl	$10, %edi
	call	putchar@PLT
	leaq	.LC3(%rip), %rsi
	movl	$1, %edi
	movl	$0, %eax
	call	__printf_chk@PLT
	leaq	8(%rsp), %rsi
	leaq	.LC2(%rip), %rdi
	movl	$0, %eax
	call	__isoc99_scanf@PLT
	movl	$10, %edi
	call	putchar@PLT
	leaq	.LC4(%rip), %rsi
	movl	$1, %edi
	movl	$0, %eax
	call	__printf_chk@PLT
	leaq	16(%rsp), %rsi
	leaq	.LC2(%rip), %rdi
	movl	$0, %eax
	call	__isoc99_scanf@PLT
	movl	$10, %edi
	call	putchar@PLT
	movq	16(%rsp), %rdx
	movq	8(%rsp), %rsi
	movq	(%rsp), %rdi
	call	decode2
	movq	%rax, %rdx
	movq	%rax, 8(%rsp)
	leaq	.LC5(%rip), %rsi
	movl	$1, %edi
	movl	$0, %eax
	call	__printf_chk@PLT
	movq	24(%rsp), %rax
	xorq	%fs:(%rbx), %rax
	jne	.L5
	movl	$0, %eax
	addq	$32, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
.L5:
	.cfi_restore_state
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE24:
	.size	main, .-main
	.ident	"GCC: (Ubuntu 9.4.0-1ubuntu1~20.04.1) 9.4.0"
	.section	.note.GNU-stack,"",@progbits
	.section	.note.gnu.property,"a"
	.align 8
	.long	 1f - 0f
	.long	 4f - 1f
	.long	 5
0:
	.string	 "GNU"
1:
	.align 8
	.long	 0xc0000002
	.long	 3f - 2f
2:
	.long	 0x3
3:
	.align 8
4:

