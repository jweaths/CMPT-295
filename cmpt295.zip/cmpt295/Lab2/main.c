/*
 * Filename: main.c
 *
 * Purpose: Lab 2
 * 
 * Last Modified: Jan. 2023
 *
 */
 
#include <stdio.h>

typedef unsigned short bit16;

void mystery(bit16, char*);

void main() {
    bit16 x = 0x1234; // hexidecimal
    //char *someStr; // no space was allocated. There was no memory to assign address
    char someStr[17] ; // changed from 16 to 17 to fix character because function was leaking null character into next array and not reading it properly
    char msg[16] = "The result is:";

    puts(msg);
    mystery(x, someStr);
    puts(someStr);

    puts(msg);
    mystery(x, someStr);
    puts(someStr);

    return;
}
