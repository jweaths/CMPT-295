/*
 * Filename: subprog.c
 *
 * Purpose: Lab 2
 * 
 * Last Modified: Jan. 2023
 *
 */
 
typedef unsigned short bit16;

char *mystery(bit16 x, char* str) { // breakpoint 1 "break mystery" in run gdb
    int i;
    for (i = 0; i < 16; i++) {
        str[i] = (char) ((x & 0x8000) >> 15) | 0x30;
        x = (x << 1) & 0xffff; // breakpoint here "break 16" in run gdb
    }
    str[16] = '\0'; // break 18
    return str;  
}
